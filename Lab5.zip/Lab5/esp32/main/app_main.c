#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "nvs_flash.h"
#include "driver/gpio.h"
#include "sdkconfig.h"
#include "driver/i2c.h"
#include "esp_err.h"

#include "dht11.h"  // Thư viện DHT11

#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_netif.h"
#include "esp_timer.h"
#include "freertos/semphr.h"
#include "freertos/queue.h"
#include "lwip/sockets.h"
#include "lwip/dns.h"
#include "lwip/netdb.h"
#include "esp_log.h"
#include "mqtt_client.h"

#define DHT_PIN GPIO_NUM_27

#define EXAMPLE_ESP_WIFI_SSID "Candy"
#define EXAMPLE_ESP_WIFI_PASS "function@321"
#define EXAMPLE_ESP_MAXIMUM_RETRY 20
#define WIFI_CONNECTED_BIT BIT0
#define WIFI_FAIL_BIT BIT1

unsigned long LastSendMQTT = 0; 

static const char *TAG = "mqtt_example";
static EventGroupHandle_t s_wifi_event_group;
static int s_retry_num = 0;

static void event_handler(void* arg, esp_event_base_t event_base, int32_t event_id, void* event_data){
    if(event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_START){
        esp_wifi_connect();
    }
    else if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_DISCONNECTED){
        if(s_retry_num < EXAMPLE_ESP_MAXIMUM_RETRY){
            esp_wifi_connect();
            s_retry_num++;
            ESP_LOGI(TAG, "Reconnecting...");
        }
        else{
            xEventGroupSetBits(s_wifi_event_group, WIFI_FAIL_BIT);   
        }
        ESP_LOGE(TAG,"Connect to the access point fail!");
    }
    else if (event_base == IP_EVENT && event_id == IP_EVENT_STA_GOT_IP){
        ip_event_got_ip_t* event = (ip_event_got_ip_t*) event_data;
        ESP_LOGI(TAG, "Got IP: " IPSTR, IP2STR(&event->ip_info.ip));
        s_retry_num = 0;
        xEventGroupSetBits(s_wifi_event_group, WIFI_CONNECTED_BIT);
    }
}

void esp_wifi_init_sta(){
    s_wifi_event_group = xEventGroupCreate();
    ESP_ERROR_CHECK(esp_netif_init());
    esp_event_loop_create_default();
    esp_netif_create_default_wifi_sta();
    wifi_init_config_t init_config = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&init_config));

    esp_event_handler_instance_t any_id;
    esp_event_handler_instance_t got_ip;

    esp_event_handler_instance_register(WIFI_EVENT, ESP_EVENT_ANY_ID, &event_handler, NULL, &any_id);
    esp_event_handler_instance_register(IP_EVENT, IP_EVENT_STA_GOT_IP, &event_handler, NULL, &got_ip);

    wifi_config_t wifi_config = {
        .sta ={
            .ssid = EXAMPLE_ESP_WIFI_SSID,
            .password = EXAMPLE_ESP_WIFI_PASS,
            .scan_method = WIFI_ALL_CHANNEL_SCAN,
        },  
    };

    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wifi_config));
    ESP_ERROR_CHECK(esp_wifi_start());

    ESP_LOGI(TAG, "esp_wifi_init_sta finish!!!");

    EventBits_t bits = xEventGroupWaitBits(s_wifi_event_group, WIFI_CONNECTED_BIT | WIFI_FAIL_BIT, pdFALSE, pdFALSE, portMAX_DELAY);
    if (bits & WIFI_CONNECTED_BIT){
        ESP_LOGI(TAG, "Connected to access point. SSID: %s, Password: %s",EXAMPLE_ESP_WIFI_SSID, EXAMPLE_ESP_WIFI_PASS);
    }
    else if(bits & WIFI_FAIL_BIT){
        ESP_LOGI(TAG, "Failed to connect to access point. SSID: %s, Password: %s",EXAMPLE_ESP_WIFI_SSID, EXAMPLE_ESP_WIFI_PASS);
    }
    else{
        ESP_LOGE(TAG,"UNEXPECTED EVENT!");
    }

}

static void log_error_if_nonzero(const char *message, int error_code)
{
    if (error_code != 0) {
        ESP_LOGE(TAG, "Last error %s: 0x%x", message, error_code);
    }
}

bool IsConnectMQTT = false;
void ConnectMQTTSendData(void *arg);
void MQTT_DataJson(void);
static esp_err_t esp_event_handler_cb(esp_mqtt_event_handle_t event);
static void mqtt_event_handler(void *handler_args, esp_event_base_t base, int32_t event_id, void *event_data);

#define MQTT_sizeof 200

char MQTT_JSON[MQTT_sizeof];
char str_temp[MQTT_sizeof];
char str_humidity[MQTT_sizeof];

char *topic_publish = "sensor/sensor1/temperature";
char *topic_subcribes = "sensor/sensor1/temperature";

void MQTT_DataJson(void)
{
    for(int i = 0 ; i < MQTT_sizeof ; i++)
    {
        MQTT_JSON[i] = 0;    
        str_temp[i] = 0;
        str_humidity[i] = 0;
    }

    sprintf(str_temp, "%d", DHT11_read().temperature);
    sprintf(str_humidity, "%d", DHT11_read().humidity);

    strcat(MQTT_JSON,"{\"temp\":\"");
    strcat(MQTT_JSON,str_temp);
    strcat(MQTT_JSON,"\",");
    
    strcat(MQTT_JSON,"\"humi\":\"");
    strcat(MQTT_JSON,str_humidity);
    strcat(MQTT_JSON,"\"}");
}

static esp_err_t mqtt_event_handler_cb(esp_mqtt_event_handle_t event)
{
    esp_mqtt_client_handle_t client = event->client;
    int msg_id;
    switch (event->event_id) {
        case MQTT_EVENT_CONNECTED:
            ESP_LOGI(TAG, "MQTT_EVENT_CONNECTED");
            msg_id = esp_mqtt_client_subscribe(client, topic_subcribes, 0);
            ESP_LOGI(TAG, "sent subscribe successful, msg_id=%d", msg_id);
            IsConnectMQTT = true;
            break;

        case MQTT_EVENT_DISCONNECTED:
            ESP_LOGI(TAG, "MQTT_EVENT_DISCONNECTED");
            IsConnectMQTT = false;
            break;

        case MQTT_EVENT_SUBSCRIBED:
            ESP_LOGI(TAG, "MQTT_EVENT_SUBSCRIBED, msg_id=%d", event->msg_id);
            break;

        case MQTT_EVENT_UNSUBSCRIBED:
            break;

        case MQTT_EVENT_PUBLISHED:
            ESP_LOGI(TAG, "MQTT_EVENT_PUBLISHED, msg_id=%d", event->msg_id);
            break;

        case MQTT_EVENT_DATA:
            printf("Messager MQTT: %.*s\r\n", event->data_len, event->data);
            char *bufData = calloc(event->data_len + 1, sizeof(char));
            snprintf(bufData, event->data_len + 1, "%s", event->data);
            printf("Data MQTT:%s\n", bufData);
            LastSendMQTT = esp_timer_get_time() / 1000;
            taskYIELD();
            free(bufData);
            break;

        case MQTT_EVENT_ERROR:
        ESP_LOGI(TAG, "MQTT_EVENT_ERROR");
        if (event->error_handle->error_type == MQTT_ERROR_TYPE_TCP_TRANSPORT) {
            ESP_LOGI(TAG, "Last error code reported from esp-tls: 0x%x", event->error_handle->esp_tls_last_esp_err);
            ESP_LOGI(TAG, "Last tls stack error number: 0x%x", event->error_handle->esp_tls_stack_err);
            ESP_LOGI(TAG, "Last captured errno : %d (%s)",  event->error_handle->esp_transport_sock_errno,
                     strerror(event->error_handle->esp_transport_sock_errno));
        } else if (event->error_handle->error_type == MQTT_ERROR_TYPE_CONNECTION_REFUSED) {
            ESP_LOGI(TAG, "Connection refused error: 0x%x", event->error_handle->connect_return_code);
        } else {
            ESP_LOGW(TAG, "Unknown error type: 0x%x", event->error_handle->error_type);
        }
        break;

        default:
            ESP_LOGI(TAG, "Other event id:%d", event->event_id);
            break;
    }
    return ESP_OK;
}

static void mqtt_event_handler(void *handler_args, esp_event_base_t base, int32_t event_id, void *event_data) {
    ESP_LOGD(TAG, "Event dispatched from event loop base=%s, event_id=%ld", base, event_id);
    mqtt_event_handler_cb(event_data);
}

void ConnectMQTTSendData(void *arg)
{	
	 const esp_mqtt_client_config_t mqtt_cfg = {	
    	.broker.address.uri = "mqtt://192.168.1.8:1883"
    };
	
	esp_mqtt_client_handle_t client = esp_mqtt_client_init(&mqtt_cfg);
    esp_mqtt_client_register_event(client, ESP_EVENT_ANY_ID, mqtt_event_handler, client);
    
	esp_err_t err = esp_mqtt_client_start(client);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Failed to start MQTT client: %s", esp_err_to_name(err));
        vTaskDelete(NULL);
        return;
    }
	
	LastSendMQTT = esp_timer_get_time()/1000;
	
	while(1)
	{
		if(esp_timer_get_time()/1000 - LastSendMQTT >= 1500)
		{
			if(IsConnectMQTT)
			{
				MQTT_DataJson();
				esp_mqtt_client_publish(client, topic_publish, MQTT_JSON, 0, 1, 0);
				ESP_LOGI(TAG, "SEND MQTT %s", MQTT_JSON);
				vTaskDelay(10000/portTICK_PERIOD_MS);	
				taskYIELD();
			}
			LastSendMQTT = esp_timer_get_time()/1000;
		}
	}
	vTaskDelete(NULL);
}

void DHT_Oled_task(void *pvParameter)
{
    // setDHTgpio(DHT_PIN);

    // SSD1306_t dev;
	// i2c_master_init(&dev, CONFIG_SDA_GPIO, CONFIG_SCL_GPIO, CONFIG_RESET_GPIO);
	// ssd1306_init(&dev, 128, 64);
	// ssd1306_clear_screen(&dev, false);
	// ssd1306_contrast(&dev, 0xff);

    DHT11_init(DHT_PIN); // Khởi tạo DHT11

	while(1) {
		struct dht11_reading dht11_data = DHT11_read();

		if (dht11_data.status == DHT11_OK) {
            float hum = dht11_data.humidity;
		    char humidity[8];
            sprintf(humidity, "%.2f %%", hum);
         
            float temp = dht11_data.temperature;
		    char temperature[12];
            sprintf(temperature, "%.2f degC", temp);

            // ssd1306_display_text(&dev, 0, humidity, 8, false);
		    // ssd1306_display_text(&dev, 2, temperature, 12, false);

            printf("Humidity %.2f %%\n", hum);
		    printf("Temperature %.2f degC\n\n", temp);
		} else {
		    printf("DHT11 read error\n");
		}

	    vTaskDelay(2000 / portTICK_PERIOD_MS);
	}
}

void app_main()
{
	esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
	
    vTaskDelay(2000 / portTICK_PERIOD_MS);

    esp_wifi_init_sta();
	xTaskCreate(&DHT_Oled_task, "DHT_Oled_task", 2048*2, NULL, 5, NULL );
    xTaskCreate(&ConnectMQTTSendData, "ConnectMQTT_SentData", 2048*2, NULL, 5, NULL);
}
