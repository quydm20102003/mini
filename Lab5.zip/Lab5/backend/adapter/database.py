import sqlite3
from datetime import datetime

class TemperatureDatabase:
    def __init__(self, db_name='temperature_data.db'):
        self.db_name = db_name
        self.connection = None
        self.cursor = None
        self.connect()
        self.create_table()

    def connect(self):
        self.connection = sqlite3.connect(self.db_name, check_same_thread=False)
        self.cursor = self.connection.cursor()

    def create_table(self):
        create_table_sql = '''
        CREATE TABLE IF NOT EXISTS temperatures (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            temperature REAL NOT NULL,
            humidity REAL NOT NULL
        )
        '''
        self.cursor.execute(create_table_sql)
        self.connection.commit()

    def save_data(self, temperature,humidity):
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        insert_sql = '''
        INSERT INTO temperatures (timestamp, temperature,humidity)
        VALUES (?, ?,?)
        '''
        self.cursor.execute(insert_sql, (timestamp, temperature,humidity))
        self.connection.commit()
    def get_all_data(self):
        select_sql = '''
        SELECT * FROM temperatures
        '''
        self.cursor.execute(select_sql)
        return self.cursor.fetchall()

    def get_latest_data(self):
        select_latest_sql = '''
        SELECT * FROM temperatures
        ORDER BY timestamp DESC
        LIMIT 1
        '''
        self.cursor.execute(select_latest_sql)
        return self.cursor.fetchone()

    def close(self):
        if self.connection:
            self.connection.close()

# Usage example

