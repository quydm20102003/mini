import paho.mqtt.client as mqtt
import json
from .database import TemperatureDatabase
class MQTTClient:
    def __init__(self, broker_address, port, topic, client_id="MQTTClient"):
        self.broker_address = broker_address
        self.port = port
        self.topic = topic
        self.client_id = client_id
        self.client = mqtt.Client(self.client_id)

        # Attach event callbacks
        self.client.on_connect = self.on_connect
        self.client.on_message = self.on_message

    def on_connect(self, client, userdata, flags, rc):
        print(f"Connected with result code {rc}")
        self.client.subscribe(self.topic)
        print(f"Subscribed to topic: {self.topic}")

    def on_message(self, client, userdata, msg):
        print(f"Received message: {msg.payload.decode()} on topic: {msg.topic}")
        if msg.topic ==self.topic:
            db = TemperatureDatabase()
            data = json.loads(msg.payload.decode())
            db.save_data(float(data["temp"]),float(data["humi"]))
            db.close()


    def connect(self):
        self.client.connect(self.broker_address, self.port, 60)
        self.client.loop_start()

    def disconnect(self):
        self.client.loop_stop()
        self.client.disconnect()
        print("Disconnected from broker")

# Example usage:
