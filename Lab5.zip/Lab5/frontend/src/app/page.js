"use client";
import Image from "next/image";
import styles from "./page.module.css";
import { useState, useEffect } from "react";
// import { Chart as ChartJS, ArcElement, Tooltip, Legend } from "chart.js";
import Chart from 'chart.js/auto';
import { Line } from "react-chartjs-2";


export default function Home() {
  let [latest, setLatest] = useState(0);
  let [all, setAll] = useState(false);
  let [hum,setHum] = useState(false)
  useEffect(() => {
    const interval = setInterval(() => {

      // Your custom logic here
      fetch('http://localhost:5000/data/latest')
        .then((res) => {
          return res.json();
        })
        .then((data) => {
          console.log(data);
          setLatest(data)
        });
      fetch('http://localhost:5000/data/all')
        .then((res) => {
          return res.json();
        })
        .then((data) => {
          let dtime =[];
          let dtemp =[];
          let dhum =[];
          for (const k in data){
            const d = data[k];
            dtime.push((d[1]));
            dtemp.push(d[2])
            dhum.push(d[3])
          }
          let data_line =  {
            labels: dtime,
            datasets: [{
              label: 'Temperature',
              data: dtemp,
              borderWidth: 1,
              fill: false,
              borderColor: 'rgb(75, 192, 192)',
              tension: 0.1
            }]
          }
          let data_hum =  {
            labels: dtime,
            datasets: [{
              label: 'Humidity',
              data: dhum,
              borderWidth: 1,
              fill: false,
              borderColor: 'rgb(75, 192, 192)',
              tension: 0.1
            }]
          }
          setAll(data_line)
          setHum(data_hum)
          console.log(data_line,data_hum)
        });

    }, 1000);
    return () => clearInterval(interval);
  }, []);
  
  return (
    <main className={styles.main}>
      <div><h1>Humidity: {latest[3]}</h1>
        <h1>Temperature: {latest[2]}</h1><h1>Date: {latest[1]}</h1></div>
      <div>
      {all && <Line
          data={all}
          width={1000}
          height={400}
          options={{
            maintainAspectRatio: false
          }}
        />}
        </div><div>
        {hum && <Line
          data={hum}
          width={1000}
          height={400}
          options={{
            maintainAspectRatio: false
          }}
        />}
        </div>
    </main>
  );
}
